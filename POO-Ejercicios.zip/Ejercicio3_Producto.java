/*
Ejercicio 3) Producto de inventario
Atributos: String codigo, String nombre, int stock, double precioUnitario, boolean activo.
Constructores: defecto y con parámetros (precio ≥ 0, stock ≥ 0).
Métodos: ingresar(int), vender(int) (no vender si stock insuficiente), descontinuar().
Reglas: formatear precio a dos decimales al exponerlo en getPrecioUnitario().
Salida: P01 - Teclado | stock: 18 | $59.90.
*/
public class Ejercicio3_Producto {
    private String codigo;
    private String nombre;
    private int stock;
    private double precioUnitario;
    private boolean activo;

    public Ejercicio3_Producto() {
        this("N/A", "Sin Nombre", 0, 0.0, true);
    }

    public Ejercicio3_Producto(String codigo, String nombre, int stock, double precioUnitario, boolean activo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.stock = Math.max(0, stock);
        this.precioUnitario = Math.max(0.0, precioUnitario);
        this.activo = activo;
    }

    public void ingresar(int cantidad) {
        if (cantidad <= 0) return;
        this.stock += cantidad;
    }

    public boolean vender(int cantidad) {
        if (cantidad <= 0) return false;
        if (cantidad > stock) return false;
        stock -= cantidad;
        return true;
    }

    public void descontinuar() { this.activo = false; }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public int getStock() { return stock; }
    public double getPrecioUnitario() { return Math.round(precioUnitario * 100.0) / 100.0; } // dos decimales
    public boolean isActivo() { return activo; }

    @Override
    public String toString() {
        return String.format("%s - %s | stock: %d | $%.2f", codigo, nombre, stock, getPrecioUnitario());
    }

    public static void main(String[] args) {
        Ejercicio3_Producto p = new Ejercicio3_Producto("P01", "Teclado", 20, 59.9, true);
        System.out.println(p);
        p.vender(2);
        System.out.println("Después de vender 2 -> " + p);
    }
}
