/*
Ejercicio 4) Película en videoclub/streaming
Atributos: String titulo, int anio, String clasificacion, int copias, int alquiladas.
Constructores: ambos; validar año ≥ 1900.
Métodos: alquilar(int edadCliente) (respetar clasificación), devolver().
Reglas: mapa simple de edad mínima por clasificacion ("G"=0, "PG13"=13, "R"=17).
Salida: Matrix (R) | disp: 1/3.
*/
import java.util.Map;
import java.util.HashMap;

public class Ejercicio4_Pelicula {
    private String titulo;
    private int anio;
    private String clasificacion;
    private int copias;
    private int alquiladas;

    private static final Map<String,Integer> edadMinima = new HashMap<>();
    static {
        edadMinima.put("G", 0);
        edadMinima.put("PG13", 13);
        edadMinima.put("R", 17);
    }

    public Ejercicio4_Pelicula() {
        this("Sin Titulo", 1900, "G", 0, 0);
    }

    public Ejercicio4_Pelicula(String titulo, int anio, String clasificacion, int copias, int alquiladas) {
        this.titulo = titulo;
        this.anio = Math.max(1900, anio);
        this.clasificacion = clasificacion;
        this.copias = Math.max(0, copias);
        this.alquiladas = Math.max(0, Math.min(alquiladas, this.copias));
    }

    public boolean alquilar(int edadCliente) {
        int min = edadMinima.getOrDefault(clasificacion, 0);
        if (edadCliente < min) return false;
        if (alquiladas >= copias) return false;
        alquiladas++;
        return true;
    }

    public boolean devolver() {
        if (alquiladas > 0) {
            alquiladas--;
            return true;
        }
        return false;
    }

    public int disponibles() { return copias - alquiladas; }

    @Override
    public String toString() {
        return String.format("%s (%s) | disp: %d/%d", titulo, clasificacion, disponibles(), copias);
    }

    public static void main(String[] args) {
        Ejercicio4_Pelicula m = new Ejercicio4_Pelicula("Matrix", 1999, "R", 3, 2);
        System.out.println(m);
        System.out.println("Alquilar (edad 16): " + m.alquilar(16)); // false (R)
        System.out.println("Alquilar (edad 18): " + m.alquilar(18)); // true
        System.out.println(m);
    }
}
