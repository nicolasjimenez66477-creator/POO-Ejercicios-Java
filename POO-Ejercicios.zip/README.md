
POO-Ejercicios - Colección de 10 ejercicios en Java
--------------------------------------------------

Contenido:
- Ejercicio1_Libro.java
- Ejercicio2_CuentaBancaria.java
- Ejercicio3_Producto.java
- Ejercicio4_Pelicula.java
- Ejercicio5_Estudiante.java
- Ejercicio6_Vehiculo.java
- Ejercicio7_Pedido.java (subido por usuario)
- Ejercicio7_MainPedido.java (subido por usuario)
- Ejercicio8_Reserva.java (subido por usuario)
- Ejercicio8_MainReserva.java (subido por usuario)
- Ejercicio9_Paciente.java (subido por usuario)
- Ejercicio9_MainPaciente.java (subido por usuario)
- Ejercicio10_Sensor.java (subido por user)
- Ejercicio10_MainSensor.java (subido por user)

Instrucciones:
- Cada archivo contiene una pequeña main() para pruebas.
- Compilar con: javac *.java
- Ejecutar: java NombreClase

Nota: Si alguno de los archivos subidos por el usuario no existe en /mnt/data, se creó un placeholder indicando que falta ese archivo.
