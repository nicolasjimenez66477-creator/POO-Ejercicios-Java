/*
Ejercicio 6) Vehículo – Consumo y autonomía
Atributos: String placa, String marca, double capacidadTanqueLitros, double combustibleActual, double kmPorLitro.
Constructores: ambos (capacidades y rendimientos > 0).
Métodos: recargar(double litros), conducir(double km) (consumir si alcanza), autonomia() → double.
Reglas: no permitir sobrellenado ni valores negativos.
Salida: ABC123 | Autonomía: 245.0 km.
*/
public class Ejercicio6_Vehiculo {
    private String placa;
    private String marca;
    private double capacidadTanqueLitros;
    private double combustibleActual;
    private double kmPorLitro;

    public Ejercicio6_Vehiculo() {
        this("XXX000", "Marca", 50.0, 0.0, 10.0);
    }

    public Ejercicio6_Vehiculo(String placa, String marca, double capacidadTanqueLitros, double combustibleActual, double kmPorLitro) {
        this.placa = placa;
        this.marca = marca;
        this.capacidadTanqueLitros = Math.max(0.0001, capacidadTanqueLitros);
        this.combustibleActual = Math.max(0.0, Math.min(combustibleActual, this.capacidadTanqueLitros));
        this.kmPorLitro = Math.max(0.0001, kmPorLitro);
    }

    public void recargar(double litros) {
        if (litros <= 0) return;
        combustibleActual = Math.min(capacidadTanqueLitros, combustibleActual + litros);
    }

    public boolean conducir(double km) {
        if (km <= 0) return false;
        double consumo = km / kmPorLitro;
        if (consumo > combustibleActual) return false;
        combustibleActual -= consumo;
        return true;
    }

    public double autonomia() {
        return combustibleActual * kmPorLitro;
    }

    @Override
    public String toString() {
        return String.format("%s | Autonomía: %.1f km", placa, autonomia());
    }

    public static void main(String[] args) {
        Ejercicio6_Vehiculo v = new Ejercicio6_Vehiculo("ABC123", "Toyota", 50.0, 24.5, 10.0);
        System.out.println(v);
        v.conducir(100);
        System.out.println("Después de 100 km -> " + v);
    }
}
