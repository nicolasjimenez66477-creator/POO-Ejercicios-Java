/*
Ejercicio 1) Libro de biblioteca
Atributos (privados): String titulo, String autor, int ejemplaresTotales, int ejemplaresPrestados.
Constructores: por defecto y con parámetros (validar no negativos).
Métodos: prestar() → boolean, devolver() → boolean, disponibles() → int.
Reglas: no prestar si no hay disponibles; no devolver si no hay prestados.
Getters/Setters: mantener invariantes (totales ≥ prestados).
Salida ejemplo: El Quijote - disp: 2/5.
*/
public class Ejercicio1_Libro {
    private String titulo;
    private String autor;
    private int ejemplaresTotales;
    private int ejemplaresPrestados;

    public Ejercicio1_Libro() {
        this("Sin Titulo", "Desconocido", 0, 0);
    }

    public Ejercicio1_Libro(String titulo, String autor, int totales, int prestados) {
        this.titulo = titulo;
        this.autor = autor;
        this.ejemplaresTotales = Math.max(0, totales);
        this.ejemplaresPrestados = Math.max(0, Math.min(prestados, this.ejemplaresTotales));
    }

    public boolean prestar() {
        if (ejemplaresPrestados < ejemplaresTotales) {
            ejemplaresPrestados++;
            return true;
        }
        return false;
    }

    public boolean devolver() {
        if (ejemplaresPrestados > 0) {
            ejemplaresPrestados--;
            return true;
        }
        return false;
    }

    public int disponibles() {
        return ejemplaresTotales - ejemplaresPrestados;
    }

    // Getters y setters (con validación)
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public int getEjemplaresTotales() { return ejemplaresTotales; }
    public void setEjemplaresTotales(int totales) {
        if (totales < 0) return;
        // mantener invariante: totales >= prestados
        if (totales < ejemplaresPrestados) ejemplaresPrestados = totales;
        this.ejemplaresTotales = totales;
    }

    public int getEjemplaresPrestados() { return ejemplaresPrestados; }
    public void setEjemplaresPrestados(int prestados) {
        if (prestados < 0) return;
        if (prestados > ejemplaresTotales) prestados = ejemplaresTotales;
        this.ejemplaresPrestados = prestados;
    }

    @Override
    public String toString() {
        return String.format("%s - %s | disp: %d/%d", titulo, autor, disponibles(), ejemplaresTotales);
    }

    // Pequeña main para prueba
    public static void main(String[] args) {
        Ejercicio1_Libro libro = new Ejercicio1_Libro("El Quijote", "Cervantes", 5, 3);
        System.out.println(libro);
        System.out.println("Prestar: " + libro.prestar()); // true -> ahora 4 prestados, disp 1/5
        System.out.println("Devolver: " + libro.devolver()); // true
        System.out.println(libro);
    }
}
