public class MainSensor {
    public static void main(String[] args) {
        Sensor s1 = new Sensor("S-01", 10.0, 30.0);

        s1.actualizarLectura(25.5); // No hace nada porque está inactivo
        s1.activar();
        s1.actualizarLectura(31.4);
        s1.mostrarInfo(); // S-01 | 31.4°C | Alarma: true.
    }
}

