/*
Ejercicio 2) Cuenta bancaria
Atributos: String titular, String numero, double saldo, boolean activa.
Constructores: defecto (saldo 0 y activa=true) y con parámetros.
Métodos: depositar(double), retirar(double) (no permitir sobregiro), bloquear(), activar().
Reglas: valores > 0; no operar si activa=false.
Getters/Setters: setter de saldo privado (solo cambiar vía métodos).
Salida: Cuenta 123-4 | Saldo: 1250000.00.
*/
public class Ejercicio2_CuentaBancaria {
    private String titular;
    private String numero;
    private double saldo;
    private boolean activa;

    public Ejercicio2_CuentaBancaria() {
        this("Sin Titular", "000-0", 0.0, true);
    }

    public Ejercicio2_CuentaBancaria(String titular, String numero, double saldo, boolean activa) {
        this.titular = titular;
        this.numero = numero;
        this.saldo = Math.max(0.0, saldo);
        this.activa = activa;
    }

    public boolean depositar(double monto) {
        if (!activa) return false;
        if (monto <= 0) return false;
        setSaldo(this.saldo + monto);
        return true;
    }

    public boolean retirar(double monto) {
        if (!activa) return false;
        if (monto <= 0) return false;
        if (monto > saldo) return false; // no sobregiro
        setSaldo(this.saldo - monto);
        return true;
    }

    public void bloquear() { this.activa = false; }
    public void activar() { this.activa = true; }

    // getter público, setter de saldo privado
    public double getSaldo() { return saldo; }
    private void setSaldo(double nuevo) { this.saldo = Math.max(0.0, nuevo); }

    public String getTitular() { return titular; }
    public void setTitular(String titular) { this.titular = titular; }

    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }

    public boolean isActiva() { return activa; }

    @Override
    public String toString() {
        return String.format("Cuenta %s | Saldo: %.2f | Activa: %b", numero, saldo, activa);
    }

    public static void main(String[] args) {
        Ejercicio2_CuentaBancaria c = new Ejercicio2_CuentaBancaria("Ana", "123-4", 1000.0, true);
        System.out.println(c);
        c.depositar(250.5);
        System.out.println("Después depósito: " + c.getSaldo());
        System.out.println("Retiro 200: " + c.retirar(200));
        c.bloquear();
        System.out.println("Intentar retirar con cuenta bloqueada: " + c.retirar(50));
        System.out.println(c);
    }
}
